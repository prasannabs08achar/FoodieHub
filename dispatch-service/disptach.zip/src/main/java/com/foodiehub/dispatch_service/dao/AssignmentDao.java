package com.foodiehub.dispatch_service.dao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AssignmentDao extends JpaRepository<Ass> {
}
