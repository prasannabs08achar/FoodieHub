package com.foodiehub.dispatch_service.service;

import com.foodiehub.dispatch_service.dao.AgentDao;
import com.foodiehub.dispatch_service.dao.AgentLocationHistoryDao;
import com.foodiehub.dispatch_service.dao.AssignmentDao;
import com.foodiehub.dispatch_service.dao.AgentScoringConfigDao;
import com.foodiehub.dispatch_service.dto.BatchAgentScoreResponse;
import com.foodiehub.dispatch_service.dto.BatchPickupLocation;
import com.foodiehub.dispatch_service.model.Agent;
import com.foodiehub.dispatch_service.model.AgentLocationHistory;
import com.foodiehub.dispatch_service.model.AgentScoringConfig;
import com.foodiehub.dispatch_service.model.AssignmentStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class BatchAgentScoringService {

    private static final double EARTH_RADIUS_KM = 6371.0;

    private static final BigDecimal ONE =
            BigDecimal.ONE;

    private static final BigDecimal HUNDRED =
            BigDecimal.valueOf(100);

    private static final long MAX_IDLE_MINUTES = 120;

    private final AgentDao agentDao;

    private final AgentLocationHistoryDao agentLocationHistoryDao;

    private final AssignmentDao assignmentDao;

    private final AgentScoringConfigDao agentScoringConfigDao;

    /**
     * Scores all eligible online agents for a batch pickup location.
     *
     * The returned list is sorted from highest score to lowest score.
     */
    @Transactional(readOnly = true)
    public List<BatchAgentScoreResponse> scoreAgents(
            BatchPickupLocation pickupLocation
    ) {

        validatePickupLocation(
                pickupLocation
        );

        AgentScoringConfig config =
                getScoringConfig();

        validateWeights(config);

        List<Agent> agents =
                agentDao.findByOnlineTrue();

        return agents.stream()
                .filter(this::isEligibleAgent)
                .map(agent ->
                        scoreAgent(
                                agent,
                                pickupLocation,
                                config
                        )
                )
                .sorted(
                        Comparator.comparing(
                                BatchAgentScoreResponse::totalScore
                        ).reversed()
                )
                .toList();
    }

    /**
     * Returns the highest-scored eligible agent.
     */
    @Transactional(readOnly = true)
    public BatchAgentScoreResponse scoreBestAgent(
            BatchPickupLocation pickupLocation
    ) {

        return scoreAgents(
                pickupLocation
        )
                .stream()
                .findFirst()
                .orElse(null);
    }

    private BatchAgentScoreResponse scoreAgent(
            Agent agent,
            BatchPickupLocation pickupLocation,
            AgentScoringConfig config
    ) {

        AgentLocationHistory latestLocation =
                agentLocationHistoryDao
                        .findTopByAgentIdOrderByRecordedAtDesc(
                                agent.getId()
                        )
                        .orElse(null);

        BigDecimal distanceScore =
                calculateDistanceScore(
                        latestLocation,
                        pickupLocation
                );

        int activeDeliveryCount =
                countActiveDeliveries(
                        agent.getId()
                );

        BigDecimal loadScore =
                calculateLoadScore(
                        activeDeliveryCount
                );

        BigDecimal acceptanceRate =
                calculateAcceptanceRate(
                        agent.getId()
                );

        BigDecimal acceptanceScore =
                acceptanceRate;

        long idleMinutes =
                calculateIdleMinutes(
                        agent
                );

        BigDecimal idleTimeScore =
                calculateIdleTimeScore(
                        idleMinutes
                );

        BigDecimal totalScore =
                distanceScore
                        .multiply(
                                config.getDistanceWeight()
                        )
                        .add(
                                loadScore.multiply(
                                        config.getLoadWeight()
                                )
                        )
                        .add(
                                acceptanceScore.multiply(
                                        config.getAcceptanceWeight()
                                )
                        )
                        .add(
                                idleTimeScore.multiply(
                                        config.getIdleTimeWeight()
                                )
                        )
                        .setScale(
                                6,
                                RoundingMode.HALF_UP
                        );

        return new BatchAgentScoreResponse(
                agent.getId(),
                agent.getUserId(),
                distanceScore,
                loadScore,
                acceptanceScore,
                idleTimeScore,
                totalScore,
                activeDeliveryCount,
                acceptanceRate,
                idleMinutes
        );
    }

    private boolean isEligibleAgent(
            Agent agent
    ) {

        if (!Boolean.TRUE.equals(
                agent.getOnline()
        )) {
            return false;
        }

        return agent.getId() != null;
    }

    private BigDecimal calculateDistanceScore(
            AgentLocationHistory latestLocation,
            BatchPickupLocation pickupLocation
    ) {

        if (latestLocation == null) {
            return BigDecimal.ZERO;
        }

        if (latestLocation.getLatitude() == null
                || latestLocation.getLongitude() == null) {

            return BigDecimal.ZERO;
        }

        BigDecimal distance =
                calculateDistance(
                        latestLocation.getLatitude(),
                        latestLocation.getLongitude(),
                        pickupLocation.latitude(),
                        pickupLocation.longitude()
                );

        /*
         * Score of 1.0 means very close.
         *
         * We normalize distance using:
         *
         * 1 / (1 + distance)
         *
         * This keeps the result between 0 and 1
         * and avoids arbitrary maximum-distance
         * constants.
         */
        return ONE
                .divide(
                        ONE.add(distance),
                        6,
                        RoundingMode.HALF_UP
                );
    }

    private BigDecimal calculateLoadScore(
            int activeDeliveryCount
    ) {

        /*
         * 1 active delivery -> 0.5
         * 2 active deliveries -> 0.333...
         * 3 active deliveries -> 0.25
         *
         * The score remains in (0,1].
         */
        return ONE
                .divide(
                        BigDecimal.valueOf(
                                activeDeliveryCount + 1L
                        ),
                        6,
                        RoundingMode.HALF_UP
                );
    }

    private BigDecimal calculateAcceptanceRate(
            UUID agentId
    ) {

        long accepted =
                assignmentDao
                        .countByAgentIdAndStatus(
                                agentId,
                                AssignmentStatus.ACCEPTED
                        );

        long declined =
                assignmentDao
                        .countByAgentIdAndStatus(
                                agentId,
                                AssignmentStatus.DECLINED
                        );

        long expired =
                assignmentDao
                        .countByAgentIdAndStatus(
                                agentId,
                                AssignmentStatus.EXPIRED
                        );

        long total =
                accepted
                        + declined
                        + expired;

        if (total == 0) {
            /*
             * New agents receive a neutral acceptance score.
             *
             * We do not give them an artificial perfect score.
             */
            return BigDecimal.valueOf(
                    0.5
            );
        }

        return BigDecimal
                .valueOf(accepted)
                .divide(
                        BigDecimal.valueOf(total),
                        6,
                        RoundingMode.HALF_UP
                );
    }

    private long calculateIdleMinutes(
            Agent agent
    ) {

        LocalDateTime lastAssignedAt =
                assignmentDao
                        .findTopByAgentIdAndStatusOrderByOfferedAtDesc(
                                agent.getId(),
                                AssignmentStatus.ACCEPTED
                        )
                        .map(assignment ->
                                assignment.getAcceptedAt()
                        )
                        .orElse(null);

        if (lastAssignedAt == null) {
            return MAX_IDLE_MINUTES;
        }

        long minutes =
                Duration.between(
                        lastAssignedAt,
                        LocalDateTime.now()
                ).toMinutes();

        return Math.max(
                0,
                Math.min(
                        minutes,
                        MAX_IDLE_MINUTES
                )
        );
    }

    private BigDecimal calculateIdleTimeScore(
            long idleMinutes
    ) {

        return BigDecimal
                .valueOf(idleMinutes)
                .divide(
                        BigDecimal.valueOf(
                                MAX_IDLE_MINUTES
                        ),
                        6,
                        RoundingMode.HALF_UP
                );
    }

    private int countActiveDeliveries(
            UUID agentId
    ) {

        return (int)
                assignmentDao
                        .countActiveAssignmentsForAgent(
                                agentId
                        );
    }

    private BigDecimal calculateDistance(
            BigDecimal latitude1,
            BigDecimal longitude1,
            BigDecimal latitude2,
            BigDecimal longitude2
    ) {

        double lat1 =
                Math.toRadians(
                        latitude1.doubleValue()
                );

        double lon1 =
                Math.toRadians(
                        longitude1.doubleValue()
                );

        double lat2 =
                Math.toRadians(
                        latitude2.doubleValue()
                );

        double lon2 =
                Math.toRadians(
                        longitude2.doubleValue()
                );

        double deltaLat =
                lat2 - lat1;

        double deltaLon =
                lon2 - lon1;

        double a =
                Math.sin(deltaLat / 2)
                        * Math.sin(deltaLat / 2)
                        + Math.cos(lat1)
                        * Math.cos(lat2)
                        * Math.sin(deltaLon / 2)
                        * Math.sin(deltaLon / 2);

        double c =
                2 * Math.atan2(
                        Math.sqrt(a),
                        Math.sqrt(1 - a)
                );

        return BigDecimal.valueOf(
                EARTH_RADIUS_KM * c
        );
    }

    private AgentScoringConfig getScoringConfig() {

        return agentScoringConfigDao
                .findFirstByOrderByUpdatedAtDesc()
                .orElseThrow(() ->
                        new IllegalStateException(
                                "Agent scoring configuration not found"
                        )
                );
    }

    private void validateWeights(
            AgentScoringConfig config
    ) {

        BigDecimal total =
                config.getDistanceWeight()
                        .add(
                                config.getLoadWeight()
                        )
                        .add(
                                config.getAcceptanceWeight()
                        )
                        .add(
                                config.getIdleTimeWeight()
                        );

        if (config.getDistanceWeight()
                .compareTo(BigDecimal.ZERO) < 0
                || config.getLoadWeight()
                .compareTo(BigDecimal.ZERO) < 0
                || config.getAcceptanceWeight()
                .compareTo(BigDecimal.ZERO) < 0
                || config.getIdleTimeWeight()
                .compareTo(BigDecimal.ZERO) < 0) {

            throw new IllegalStateException(
                    "Agent scoring weights cannot be negative"
            );
        }

        if (total.compareTo(
                BigDecimal.ONE
        ) != 0) {

            throw new IllegalStateException(
                    "Agent scoring weights must sum to 1.0"
            );
        }
    }

    private void validatePickupLocation(
            BatchPickupLocation pickupLocation
    ) {

        if (pickupLocation == null
                || pickupLocation.latitude() == null
                || pickupLocation.longitude() == null) {

            throw new IllegalArgumentException(
                    "Batch pickup coordinates are required"
            );
        }

        double latitude =
                pickupLocation.latitude()
                        .doubleValue();

        double longitude =
                pickupLocation.longitude()
                        .doubleValue();

        if (latitude < -90
                || latitude > 90) {

            throw new IllegalArgumentException(
                    "Invalid pickup latitude"
            );
        }

        if (longitude < -180
                || longitude > 180) {

            throw new IllegalArgumentException(
                    "Invalid pickup longitude"
            );
        }
    }
}